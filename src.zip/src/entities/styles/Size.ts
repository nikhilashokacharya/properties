export default interface Size {
    left: string,
    top: string,
    width: string,
    height: string
}
