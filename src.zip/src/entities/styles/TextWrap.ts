export interface TextWrap {
    wordWrap: string,
    overflow: string,
    whiteSpace: string
}