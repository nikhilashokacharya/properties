export interface Visibility {
    backgroundColor: string,
    borderColor: string,
    border: string,
    // borderStyle: string,
    fontFamily: string,
    textAlign: string,
    color: string,
    cursor: string,
    boxShadow: string,
}