<template>
  <fieldset class="fieldset">
    <legend>Frame1</legend>
  </fieldset>
</template>

<script>
export default {};
</script>

<style scoped>
.fieldset{
    width: 250px;
    height:200px;
    border: 1px solid gray;
}
</style>