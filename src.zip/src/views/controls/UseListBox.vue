<template>
  <iframe class="listbox"></iframe>
</template>

<script>
export default {

}
</script>

<style scoped>
.listbox{
    height: 100px;
    width:85px;
}
</style>