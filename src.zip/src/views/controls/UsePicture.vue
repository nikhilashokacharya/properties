<template>
  <iframe class="picture">
</iframe>
</template>

<script>
export default {

}
</script>

<style scoped>
.picture{
    height: 100px;
    width:85px;
    background-color:  rgb(238, 238, 238);
    border: 0.7px solid black;
}

</style>